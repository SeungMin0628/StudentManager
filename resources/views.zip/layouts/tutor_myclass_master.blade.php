<?php
/**
 * Created by PhpStorm.
 * 페이지 설명: <지도교수> 내 지도반관리 페이지 관련 최상위 페이지
 * User: Seungmin Lee
 * Date: 2018-04-01
 * Time: 오후 9:39
 */
?>
@extends('layouts.tutor_master')
@section('body.section')
    @include('partials.tutor_myclass_submenu')
@endsection