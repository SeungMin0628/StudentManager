<?php
/**
 * Created by PhpStorm.
 * User: Seungmin Lee
 * Date: 2018-03-26
 * Time: 오후 7:10
 */
?>
@extends('layouts.master')
@section('body.header')
    @include('partials.tutor_toolbar')
    @include('partials.logout')
@endsection