<?php
/**
 * Created by PhpStorm.
 * User: Seungmin Lee
 * Date: 2018-03-29
 * Time: 오후 7:48
 */
?>
@extends('layouts.forgot_master')
@section('body.section')
    <input type="button" id="button_search_id" value="@lang('account.search_id')">
    <input type="button" id="button_search_password" value="@lang('account.search_password')"><br>
    현재 보류
@endsection