<?php
/**
 * Created by PhpStorm.
 * User: Seungmin Lee
 * Date: 2018-03-26
 * Time: 오후 7:29
 */
?>
@extends('layouts.master')
@section('body.section')
    <p>{{ $description }}</p>
@endsection
