<?php
/**
 * Created by PhpStorm.
 * User: Seungmin Lee
 * Date: 2018-03-26
 * Time: 오후 7:08
 */
?>
@extends('layouts.student_master')
@section('body.section')
    메인 페이지
@endsection