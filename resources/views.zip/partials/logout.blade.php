<?php
/**
 * Created by PhpStorm.
 * User: Seungmin Lee
 * Date: 2018-03-27
 * Time: 오후 12:32
 */
?>
<span><a href="{{ route('home.logout') }}">@lang('interface.logout')</a></span>
