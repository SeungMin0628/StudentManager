<?php
/**
 * Created by PhpStorm.
 * User: Seungmin Lee
 * Date: 2018-03-26
 * Time: 오후 7:10
 */
?>
<span>&lt;지도교수&gt;프로젝트 로고</span>
<span>회원정보</span>
<span><a href="{{ route('tutor.myclass.attendance') }}">지도반</a></span>
<span>상담 관리</span>
<span>설정&관리</span>