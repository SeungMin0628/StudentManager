<?php
/**
 * Created by PhpStorm.
 * User: Seungmin Lee
 * Date: 2018-03-26
 * Time: 오후 7:10
 */
?>
<span>&lt;교과목교수&gt;프로젝트 로고</span>
<span>회원정보</span>
<span>수강반</span>
<span>상담 관리</span>
