<?php
/**
 * Created by PhpStorm.
 * 페이지 설명: <지도교수> 내 지도반 관리 관련 보조메뉴
 * User: Seungmin Lee
 * Date: 2018-04-01
 * Time: 오후 9:39
 */
?>
<div>@lang('attendance.title')</div>
<div>@lang('attendance.manage_student')</div>
<div>@lang('attendance.care_alert')</div>